function writeResponse (response) {
    
    // 응답헤더를 만듭니다. (응답헤더는 웹브라우저로 보내지는 문서의 종류지정)
    // 응답헤더는 두가지 매개변수 
    //    1. 응답코드: 서버에서 실행결과의 종류를 의미하는 숫자
    //       200 : 서버실행성공, 404: 서버에서 문서 찾지못함 500: 서버실행중 에러
    //    2. {'Content-Type': 'text/html; charset=utf-8'} : 이설정이 기본
    //       웹브라우저 받은문서를 해독 하는 방법
    //       'Content-Type' : 문서형식 (예: 그림 문서다 동영상 파일...)
    //       기본설정 'text/html' : 텍스트인데 html문서
    //       ; : 구분기호,  'charset=utf-8' : html문서에 한글이 있으면
    
    //// 비즈니스로직
    // 응답내용 작성
    // response.end('웹브라우저에 출력한 메세지') : 응답내용을 보냅니다.
    /** 실제 비즈니스 로직을 구현하는 자리 */
    // 1부터 10000까지 덧셈결과 출력
    let i = 0 // 현재 루프번호
    let sum = 0 // 1에서 10000까지의 누적합변수
    for (i = 1; i <= 10000; i++) {
        sum = sum + i
    }

    /// 응답출력 전송
    response.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
    response.end(`${1} + ... + ${10000} = ${sum}`)
}

/// HTML태그 만들기
///  매개변수 response 응답관련 변수
function createHTMLTag(response) {
    /// HTML 태그 만들기
    let writeMsg = `
        <h1 style="color: red; border: 1px solid green">안녕하세요 node.js </h1>
        <h2 style="color: blue; border: 2px solid green">안녕하세요 node.js </h2>
        <h3 style="color: green; border: 3x solid green">안녕하세요 node.js </h3>
        <h4 style="color: pink; border: 4px solid green">안녕하세요 node.js </h4>
        <h5 style="color: yellow; border: 5px solid green">안녕하세요 node.js </h5>
        <h6 style="color: orange; border: 6px solid green">안녕하세요 node.js </h6>                                        
    `
    /// 응답출력 
    response.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
    response.end(writeMsg)
}

const { create } = require('domain')
// 백앤드 서버를 만들려면
// 이미 만들어진 모듈을 사용해야합니다.
// 1. 서버모듈 : 간단하게 서버만들어줌
//    'http':기본서버기능, 
//    'express': 웹서버모든 기능을 기본적으로
//          만들어져서 우리는 추가하면됩니다.         
// 2. 인터넷주소 분석
// node.js 특유문법
// require 함수: 지정된 모듈을 가져와라

let http = require('http')
// 서버기능구현
// http.createServer(콜백함수정의(request, response))
// 웹브라우저가 데이터를 요청(=request)하면 서버에서 데이터를 
//  생성하여 응답(=response)한다.
//     매개변수 : 
//        request = 웹브라우저 요청정보에 대한 변수
//        response = 웹서버에서 요청을 분석해서 원하는
//                    데이터를 만들어서 웹브라우저로 
//                   보낼 응답데이터 변수              
let server = http.createServer(function(request, response) {
    ////////////////////////////////////
    /////  비즈니스로직 시작
    ///////////////////////////////////
    ///writeResponse(response) /// 비즈니스로직 처리함수
    createHTMLTag(response)
    /////////////////////////////////
    ///// 비즈니스로직 끝
    /////////////////////////////////
})

// 3. listen함수로 9000포트로 서버를 대기상태로 실행한다.
//    서버실행중임을 화면에 출력....
let serverPort = 80
server.listen(serverPort, function() {
    console.log(`Server is running at http://127.0.0.1:${serverPort}`)
})